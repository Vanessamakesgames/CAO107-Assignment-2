///////////////////////////////////////////////////////////////
//  -------------
//  dmgui.h
//  -------------
//  Helper functions and bits for the CAO107 imgui + SDL2
//  setup for weeks 5-8.
//
///////////////////////////////////////////////////////////////

#pragma once
#include <SDL.h>
#include <SDL_opengl.h>
#include <string>
#include <SDL_mixer.h>

namespace DmGui 
{
  struct MLoad_Image
  {
    GLuint texture_id{0};
    int width {0};
    int height {0};
    std::string error;
    std::string path_name;
    std::string name;
    bool is_visible {false};
    bool is_loaded {false};
    int load_time{0};
  };

  struct MLoad_Sound
  {
    Mix_Music* p_sound { nullptr };
    std::string name;
    std::string path_name;
    int load_time {0};
    bool is_loaded {false};
    bool is_playing{ false };
    bool is_open{ false };
  };

  struct LoadOptions
  {
    bool done{ false };
    bool show_demo_window = false;
    bool show_load_window = true;
    bool thread {false};
    bool multiple_threads {false};
    bool show_loaded{ false };
    int number_of_threads{ 0 };
    int system_max_supported_threads{ 0 };
    bool load_threads{ false };
    bool destroy_threads{ false };
    int music_volume{ 64 };
  };
  
  // Takes a path to an image and (a reference to) and loads it using SDL2_image.
  // It converts the result to an Open GL 2D texture and puts the id etc into
  // the DmGui ImageTexture you supply. 
  std::string Load_Image_To_GLuint_Texture(std::string path, DmGui::MLoad_Image& image_texture);
}
