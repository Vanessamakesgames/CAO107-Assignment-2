#include "timer.h"

using namespace torrens;
using namespace std::chrono;

torrens::Timer::Timer()
{
	startTime_ = steady_clock::now();
	stopTime_ = steady_clock::now();
}

float
torrens::Timer::timeTakenMilli()
{
	auto timeTaken = stopTime_ - startTime_;
	auto timeTakenMicro = duration_cast<microseconds>(timeTaken);
	

	return timeTakenMicro.count() / 1000.0f;;
}

steady_clock::time_point 
torrens::Timer::start()
{
	startTime_ = steady_clock::now();
	return startTime_;
}

steady_clock::time_point
torrens::Timer::stop()
{
	stopTime_ = steady_clock::now();
	return steady_clock::now();
}
