#include "MyThreads.h"


std::deque<VhGui::Tasks> queue;
std::condition_variable cv;
std::mutex Lock;

void VhGui::MyThreads::Infinite_loop_function()
{	
	VhGui::Tasks task;
	VhGui::Queue Q;
	Image pic;
	Sound audio;
	while (!&DmGui::LoadOptions::destroy_threads)
	{
		{
			std::unique_lock<std::mutex> lock(Lock);

			cv.wait(lock, [] {return !queue.empty() || &DmGui::LoadOptions::destroy_threads; });
			
			if (Q.queue.front().image.name != "") task.image = Q.queue.front().image;
			if (Q.queue.front().sound.name != "") task.sound = Q.queue.front().sound;
			queue.pop_front();
		}
		if (task.image.name != "") pic.Load_Image(task.image);
		if (task.sound.name != "") audio.Load_Sound(task.sound);
	}
}

//void VhGui::MyThreads::Add_image_job(std::function<void (DmGui::MLoad_Image&)> New_job)
//{
//	Tasks t;
//	t.image_job = New_job;
//	{
//		std::unique_lock<std::mutex> lock(Lock);
//		VhGui::Queue Q;
//		Q.queue.push_back(t);
//	}
//	cv.notify_one();
//}
//
//void VhGui::MyThreads::Add_sound_job(std::function<void(DmGui::MLoad_Sound&)> New_job)
//{
//	Tasks t;
//	t.sound_job = New_job;
//	{
//		std::unique_lock<std::mutex> lock(Lock);
//		VhGui::Queue Q;
//		Q.queue.push_back(t);
//	}
//	cv.notify_one();
//}

void VhGui::MyThreads::Add_job(Tasks task)
{
	VhGui::Queue Q;
	Q.queue.push_back(task);
}

void VhGui::shutdown(DmGui::LoadOptions& options)
{
	std::unique_lock<std::mutex> lock(Lock);
	options.destroy_threads = true;

	cv.notify_all();

	for (std::thread& every_thread : workers) every_thread.join();

	workers.clear();
	options.done = true;
}

void VhGui::Image::Load_Image(DmGui::MLoad_Image& image)
{
	torrens::Timer timer;
	timer.start();
	image.error = Load_Image_To_GLuint_Texture(image.path_name, image);
	timer.stop();
	image.load_time = timer.timeTakenMilli();
	Open_Image(image);
}

void VhGui::Image::Open_Image(DmGui::MLoad_Image& image)
{
	if (image.texture_id > 0 && image.is_visible != 0)
	{
		ImGuiWindowFlags window_flags = 0;
		ImGui::Begin(image.name.c_str(), &image.is_visible, window_flags);
		ImGui::Text("Resolution: %dx%d", image.width, image.height);
		ImGui::Image((void*)(intptr_t)image.texture_id, ImVec2((float)image.width, (float)image.height), ImVec2(0.0f, 0.0f), ImVec2(1.0f, 1.0f));
		ImGui::End();
	}

	if (!image.path_name.empty())
	{
		ImGui::Text("Pathname: %s", image.path_name.c_str());
		if (!image.error.empty())
			ImGui::Text("Image load error: %s", image.error.c_str());
	}
}

void VhGui::Sound::Load_Sound(DmGui::MLoad_Sound& sound)
{
	torrens::Timer timer;
	timer.start();
	sound.p_sound = Mix_LoadMUS(sound.path_name.c_str());
	if (!sound.p_sound)
	{
		printf("Mix_LoadMUS(\"music.mp3\"): %s\n", Mix_GetError());
	}
	timer.stop();
	sound.load_time = timer.timeTakenMilli();
	sound.is_loaded = true;
	Open_Sound(sound);
}

void VhGui::Sound::Open_Sound(DmGui::MLoad_Sound& sound)
{
	ImGuiWindowFlags window_flags = 0;
	ImGui::Begin(sound.name.c_str(), &sound.is_open, window_flags);
	ImGui::Text(sound.name.c_str());
	ImGui::SameLine();
	ImGui::Text("- Time taken: %dms", sound.load_time);
	ImGui::SameLine();
	if (ImGui::Button("Play from start"))
	{
		sound.is_playing = true;
		Mix_FadeInMusic(sound.p_sound, 1, 1000);

	}
	ImGui::SameLine();
	if (ImGui::Button("Pause / Unpause"))
	{
		// 0 = music not playing
		if (sound.is_playing)
		{
			sound.is_playing = false;
			Mix_PauseMusic();
		}
		else
		{
			sound.is_playing = true;
			Mix_ResumeMusic();
		}

	}
	ImGui::SameLine();
	if (ImGui::Button("Stop"))
	{
		sound.is_playing = false;
		Mix_FadeOutMusic(500);
	}
	ImGui::End();
}
