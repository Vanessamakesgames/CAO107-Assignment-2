#pragma once
#include "dmgui.h"
#include <queue>
#include <vector>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <functional>
#include "main.cpp"
template< class >
class function;

namespace VhGui
{

	class MyThreads
	{
	public:
		void Infinite_loop_function();
		void Add_job(VhGui::Tasks task);
	};

	struct Tasks
	{
	public:
		DmGui::MLoad_Image image;
		DmGui::MLoad_Sound sound;
	};

	struct Queue
	{
		static std::deque<Tasks> queue;
	};

	void shutdown(DmGui::LoadOptions& options);

	class Image
	{
	public:
		void Load_Image(DmGui::MLoad_Image& image);
		void Open_Image(DmGui::MLoad_Image& image);
	};

	class Sound
	{
	public:
		void Load_Sound(DmGui::MLoad_Sound& sound);
		void Open_Sound(DmGui::MLoad_Sound& sound);
	};
}